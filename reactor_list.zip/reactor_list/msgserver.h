#ifndef MSGSERVER_H
#define MSGSERVER_H

#include "tcpserver.h"
#include "msgsocket.h"

typedef struct MsgServer{

    TcpServer *m_tcpServer;

}MsgServer;

void MsgServerCreate(MsgServer *msgserver, EventLoop *loop, ThreadPool *pool, short port);
void MsgServerStop(MsgServer *msgserver);

void NewTcpConnection(MsgServer *msgserver, TcpSocket *socket);

#endif // MSGSERVER_H
