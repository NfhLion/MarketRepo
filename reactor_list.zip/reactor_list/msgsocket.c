#include "msgsocket.h"


void MsgSocketCreate(MsgSocket *msgsocket, TcpSocket *socket)
{
    msgsocket->m_msgQueue_first = NULL;
    msgsocket->m_msgQueue_tail = NULL;
    msgsocket->m_tcpSocket = socket;
    msgsocket->m_tcpSocket->RecvFunc = RecvMsg;
    msgsocket->m_tcpSocket->arg = msgsocket;
}

void RecvMsg(MsgSocket *msgsocket, char *msg)
{
    //将读到的数据加到消息队列里
    MsgQueueN *node = (MsgQueueN *)malloc(sizeof(MsgQueueN));
    memset(node, 0, sizeof(MsgQueueN));
    strcpy(node->buf, msgsocket->m_tcpSocket->read_buf);
    LL_ADD(node, msgsocket->m_msgQueue_first, msgsocket->m_msgQueue_tail);

    NJob *job = JobNodeCreate(ParseMsg, (void *)msgsocket);
    ThreadPoolPush(msgsocket->m_tcpSocket->pool, job);
}

void ParseMsg(MsgSocket *msgsocket)
{
    MsgQueueN *node = msgsocket->m_msgQueue_first;
    if(node == NULL)
    {
        printf("m_msgQueue is NULL\n");
        exit(1) ;
    }
    char msg[BUFSIZ] = "";
    strcpy(msg, node->buf);
    LL_REMOVE(node, msgsocket->m_msgQueue_first, msgsocket->m_msgQueue_tail);
    free(node);

    int i = 0, j = 0;
    for(j = 0; j < 100000; j++){
        for(i = 0; i < strlen(msg); i++)
        {
            if((msg[i] > ('a'-1)) && (msg[i] < ('z'+1)))
            {
                msg[i] -= 32;
            }
        }
        for(int i = 0; i < strlen(msg); i++)
        {
            if((msg[i] > ('A'-1)) && (msg[i] < ('Z'+1)))
            {
                msg[i] += 32;
            }
        }
        for(int i = 0; i < strlen(msg); i++)
        {
            if((msg[i] > ('a'-1)) && (msg[i] < ('z'+1)))
            {
                msg[i] -= 32;
            }
        }
    }

    SendMsg(msgsocket->m_tcpSocket, msg);
}
