#ifndef MSGSOCKET_H
#define MSGSOCKET_H

#include "tcpsocket.h"

//消息队列
typedef struct MsgQueue{
    char buf[BUFSIZ];
    struct MsgQueue *next;
    struct MsgQueue *prev;
}MsgQueueN;

typedef struct MsgSocket{

    struct MsgQueue *m_msgQueue_first;
    struct MsgQueue *m_msgQueue_tail;

    TcpSocket *m_tcpSocket;
}MsgSocket;

void MsgSocketCreate(MsgSocket *msgsocket, TcpSocket *socket);
void RecvMsg(MsgSocket *msgsocket, char *msg);
void ParseMsg(MsgSocket *msgsocket);

#endif // MSGSOCKET_H
