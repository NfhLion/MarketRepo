#include "msgserver.h"

void MsgServerCreate(MsgServer *msgserver, EventLoop *loop, ThreadPool *pool, short port)
{
    msgserver->m_tcpServer = (TcpServer *)malloc(sizeof(TcpServer));
    if(msgserver->m_tcpServer == NULL){
        printf("malloc m_tcpserver failed!\n");
        exit(1);
    }
    msgserver->m_tcpServer->arg = msgserver;
    msgserver->m_tcpServer->NewConnection = NewTcpConnection;
    ServerCreate(msgserver->m_tcpServer, loop, pool, port);
}


void NewTcpConnection(MsgServer *msgserver, TcpSocket *socket)
{
    MsgSocket *msgsocket = (MsgSocket *)malloc(sizeof(MsgSocket));
    if(msgsocket == NULL)
        exit(1);
    MsgSocketCreate(msgsocket, socket);
}


void MsgServerStop(MsgServer *msgserver)
{
    ServerStop(msgserver->m_tcpServer);
}
